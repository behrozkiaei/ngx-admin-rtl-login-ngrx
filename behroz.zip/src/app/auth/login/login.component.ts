import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';
import { NbAuthService, NbLoginComponent } from '@nebular/auth';
import { Store } from '@ngrx/store';
import * as userActions from '../../@core/state/user.actions';
@Component({
  selector: 'ngx-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.scss']
})
export class LoginComponent extends NbLoginComponent  implements OnInit {
  showMessages: any;
  constructor(service: NbAuthService, cd: ChangeDetectorRef, router: Router,private store: Store){
    super(service,{},cd,router)
  };
 
  ngOnInit(): void {
  }
  login(): void {
      console.log("behrozkaeii")
      this.store.dispatch(userActions.login({ username: this.user.email, password: this.user.password }));
  }
}
