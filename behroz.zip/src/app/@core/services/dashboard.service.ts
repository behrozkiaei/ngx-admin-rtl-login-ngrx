import { Injectable } from '@angular/core';
import { Observable, of } from 'rxjs';
import { delay } from 'rxjs-compat/operator/delay';
import { ApiService } from './api.service';
import {IResponseAPI ,Dashboard} from "../../@core/models/dashboard.model"
@Injectable({
  providedIn: 'root'
})
export class DashboardService {

  constructor(private apiService : ApiService) { }

  getCount():Observable<IResponseAPI<Dashboard>>{
  return this.apiService.get("/operator/dataCount")
  }

}
