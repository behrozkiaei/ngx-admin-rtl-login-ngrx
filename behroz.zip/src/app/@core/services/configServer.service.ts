import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { Application } from '../models/configServer.interface';
import { assignAppToCategory, assignCategoryToConfigProperty } from '../models/dashboard.model';
import { INewResponseAPI, IResponseAPI } from '../models/Response.interface';
// import { opearatorRoles, ConfigServer, operators, updateOperator } from '../models/ConfigServer.interface';
import { ApiService } from './api.service';
import { NewApiService } from './NewApi.Service';

@Injectable({
  providedIn: 'root'
})
export class ConfigServerService {

  constructor(private apiService :NewApiService) {

   }

    // Application services
   public getAllApplication(): Observable<INewResponseAPI<Array<Application>>> {
     return this.apiService.get('/config/getAllApp')

   }
   public deleteApplicationItem(AppId): Observable<INewResponseAPI<Application>> {
     return this.apiService.delete(`/config/deleteAppById/${AppId}`)

   }
   public addApplicationItem(data): Observable<INewResponseAPI<Application>> {
     return this.apiService.post(`/config/addApp`, data)

   }
   public updateApplicationItem(data): Observable<INewResponseAPI<Application>> {
     let {id ,...payload} = data;
     let params = new URLSearchParams(payload).toString();
     return this.apiService.update(`/config/updateAppById/${id}`,data)

   }



   // Categories services
   public getAllCategories(): Observable<INewResponseAPI<any>> {
    return this.apiService.get('/config/getAllCategory')
  } 
  public getCategoryItem(id): Observable<INewResponseAPI<any>> {
    return this.apiService.get(`/config/getCategoryById/${id}`)
  }
  public deleteCategoryItem(id): Observable<any> {
    return this.apiService.delete(`/config/deleteCategoryById/${id}`)
  }
  public addCategoryItem(data): Observable<INewResponseAPI<any>> {
    return this.apiService.post(`/config/addCategory`, data)
  }
  public updateCategoryItem(data): Observable<INewResponseAPI<any>> {
    let {id ,...payload} = data;
    let params = new URLSearchParams(payload).toString();
    return this.apiService.update(`/config/updateCategoryById/${id}`,payload)
  }



//  Property services
  public getAllProperties(): Observable<INewResponseAPI<any>> {
    return this.apiService.get('/config/getAllConfigProperty')
  } 
  public getPropertyItem(id): Observable<INewResponseAPI<any>> {
    return this.apiService.get(`/config/getConfigById/${id}`)
  }
  public deletePropertyItem(id): Observable<INewResponseAPI<any>> {
    return this.apiService.delete(`/config/deleteConfigById/${id}`)
  }
  public addPropertyItem(data): Observable<INewResponseAPI<any>> {
    let {typeMaster,...payload} = data;
    payload.type = typeMaster;
    return this.apiService.post(`/config/addConfigProperty`, payload)
  }
  public updatePropertyItem(data): Observable<INewResponseAPI<any>> {
    let {id ,typeMaster,...payload} = data;
    payload.type = typeMaster;
    return this.apiService.update(`/config/updateConfigById/${id}`,payload)
  }


  public assignCategoryToConfigProperty(data : assignCategoryToConfigProperty){
    return this.apiService.post(`/config/assignCategoryToConfigProperty`, data)
  }

  public assignAppToCategory(data :assignAppToCategory){
    return this.apiService.post(`/config/assignAppToCategory`, data)
  }

}