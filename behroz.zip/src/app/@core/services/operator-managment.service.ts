import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { IResponseAPI } from '../models/Response.interface';
import { opearatorRoles, OperatorManagment, operators, updateOperator } from '../models/operatorManagment.interface';
import { ApiService } from './api.service';

@Injectable({
  providedIn: 'root'
})
export class OperatorManagmentService {

  constructor(private apiService : ApiService) {

   }


   getOperators():Observable<IResponseAPI<OperatorManagment>>{
    return this.apiService.get("/operator")
   }
   registerOperators(paylaod):Observable<IResponseAPI<operators>>{
    return this.apiService.post("/operator/register",paylaod)
   }
   getRoles():Observable<IResponseAPI<opearatorRoles[]>>{ 
    return this.apiService.get("/baseInfo/operatorRoles")
   }
   updateOperator(paylaod):Observable<IResponseAPI<updateOperator>>{
    return this.apiService.post("/operator",paylaod)
   }

   fetchUser(userId):Observable<IResponseAPI<operators>>{
    return this.apiService.get(`/operator/${userId}`)
   }
}
