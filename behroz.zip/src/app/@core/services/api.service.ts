import { Injectable } from '@angular/core';
import { HttpClient } from '@angular/common/http';
import { environment } from '../../../environments/environment';
import { Observable } from 'rxjs';

@Injectable()
export class ApiService {
  baseUrl:string =environment.APIEndpoint;
  
  constructor(private httpClient : HttpClient) { 
    
  }
  
  get(rout):Observable<any>{
    return this.httpClient.get(this.baseUrl + rout);
  }
  post(rout,payload):Observable<any>{
    return this.httpClient.post(this.baseUrl + rout,payload);
  }
  delete(rout):Observable<any>{
    return this.httpClient.delete(this.baseUrl + rout);
  }
  update(rout,data):Observable<any>{
    return this.httpClient.put(this.baseUrl + rout,data);
  }

}