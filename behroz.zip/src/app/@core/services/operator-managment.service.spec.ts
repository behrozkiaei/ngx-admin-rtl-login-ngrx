import { TestBed } from '@angular/core/testing';

import { OperatorManagmentService } from './operator-managment.service';

describe('OperatorManagmentService', () => {
  let service: OperatorManagmentService;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    service = TestBed.inject(OperatorManagmentService);
  });

  it('should be created', () => {
    expect(service).toBeTruthy();
  });
});
