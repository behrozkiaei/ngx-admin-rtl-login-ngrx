export interface OperatorManagment
{
  operators : operators[]
}

  export interface operators {
    enabled?: boolean,
    firstName?: string,
    lastName?: string,
    operatorRole?: operatoRole,
    uniqueId?: string,
    username?: string,
    enablePersian?: string
  }


export interface opearatorRoles{
      id: number, 
      roleName: string
}
    
// registerPayload
export interface registerPayload{
  firstName?:string,
  lastName?:string,
  username?:string,
  password?:string,
  rePass?:string,
  roleId:number
}

export interface updateOperator{
  uniqueId:string,
  username:string,
  firstName:string,
  lastName:string,
  operatorRole:operatoRole,
  enabled:boolean,
  roleId:number,
  role:string,
  userId:string,
  operatorUniqueId:string
}
export interface operatoRole{
  id:number,
  roleName:string
}