export interface Dashboard
    {
        usersCount?:number,
        versionCount?:number,
        operatorsCount?:number,
        merchantsCount?:number,
        suggestionsCount?:number
    }
export interface DashboardResponse {
    code? : number,
    content?: Dashboard
}

export interface IResponseAPI<T> {
    code: number;
    content: T;
    errorUrl: string;
    message: string;
  }

  export interface assignCategoryToConfigProperty{
    categoryId: string,
    configPropertyId: string
  }
  export interface assignAppToCategory{
        appId: string,
        categoryId: string 
  }
  