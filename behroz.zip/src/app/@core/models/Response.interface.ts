export interface IResponseAPI<T> {
    code: number;
    content: T;
    errorUrl: string;
    message: string;
  }

  export interface INewResponseAPI<T> {
    responseCode: string;
    responseBody: T;
    message: string;
  }

