export interface ConfigServerManagmentState {
  ApplicationManagmentData: Application[],
  CategoryManagmentData: Category[],
  PropertyManagmentData: Property[],
  Applicationloading? :boolean,
  Categoryloading? :boolean,
  Propertyloading? :boolean,
  Applicationerror? : string,
  Categoryerror? : string,
  Propertyerror? : string,
}
export interface Bank {
  banks: Array<BankDetails>;
}
export interface BankDetails {
  key: string;
  nameEn: string;
  nameFa: string;
  id: number;
}

export interface RequestType {
  description: string;
  key: string;
}

export interface Business {
  creation: Date;
  detailsUrl: string;
  enabled: boolean;
  icon: string;
  titleEn: string;
  titleFa: string;
  uniqueId: string;
}
export interface CardBank {
  nameFa: string;
}

export interface Version {
  active: boolean;
  platform: string;
  version: string;
}
export interface Status {
  status: string;
  statusNameFa: string;
  statusNameEn: string;
}

export interface MobileOperator {
  operators: Array<MobileOperatorDetails>;
}

export interface MobileOperatorDetails {
  active: boolean;
  billInquiryEnabled: boolean;
  chargeTypes: ChargeType[];
  customChargeEnabled: boolean;
  key: string;
  maxCustomChargeAmount: string;
  minCustomChargeAmount: string;
  nameEn: string;
  nameFa: string;
  operatorTopUpList: number[];
  order: number;
  packagePurchaseEnabled: boolean;
  packages: PackageDetails[];
  preCodes: string[];
  topUpEnabled: boolean;
  topUpList: TopUpDetails[];
}

export interface ChargeType {
  chargeType: string;
  name: string;
}

export interface PackageDetails {
  id: number;
  packageTypeKey: number;
  price: number;
  priceWithoutVat: number
  subCategoryName: string;
  titleEn: string;
  titleFa: string;
}

export interface TopUpDetails {
  pkgId: string;
  price: number;
  priceWithoutVat: number;
  topUpAmount: number;
}

export interface Application {
    id: number;
    name?: string;
    description?: string;
    inProgress?: boolean;

}
export interface Category {
  id: string;
  name?: string;
  description?: string;
}

export interface Property {
    id: string;
    key: string;
    value: string;
    regex: string;
    description: string;
    type: string;
}
export enum Type{
    STRING ,
    NUMBER,
    DATE ,
    BOOLEAN 
}

