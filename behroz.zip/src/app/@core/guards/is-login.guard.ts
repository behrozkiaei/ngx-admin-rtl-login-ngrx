import { Injectable } from '@angular/core';
import { ActivatedRouteSnapshot, CanActivate, Router, RouterStateSnapshot, UrlTree } from '@angular/router';
import { select, Store } from '@ngrx/store';
import { map } from 'rxjs/operators';
import { Observable } from 'rxjs';
import { User } from '../models/user.model';
import * as userSelectors from '../state/user.selectors';
@Injectable({
  providedIn: 'root'
})
export class IsLoginGuard implements CanActivate {
  constructor(private router: Router,private store: Store) {}
  canActivate(route: ActivatedRouteSnapshot,state: RouterStateSnapshot): Observable<boolean | UrlTree> | Promise<boolean | UrlTree> | boolean | UrlTree {
    
    return this.store.pipe(
      select(userSelectors.selectUser),
      map((user: User) => {
        console.log("user",user)
        if (!!user) {
          return true;
        }else{
          this.router.navigate(['auth']);
          return false;
        }
      }),
      );
  }
  
}
