import { Injectable } from '@angular/core';
import { HttpInterceptor, HttpEvent, HttpResponse, HttpRequest, HttpHandler, HttpHeaders } from '@angular/common/http';
import { Observable } from 'rxjs';

@Injectable()
export class CustomInterceptor implements HttpInterceptor {
  intercept(httpRequest: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {
    const headers = new HttpHeaders({
        'Content-type': 'application/json; charset=utf-8',
        'X-BuildNo': '1',
        'X-Platform': 'Web',
        'X-Version': '1.0',
        'Access-Control-Allow-Origin': '*',
        'Access-Control-Allow-Methods': '*',
        'Access-Control-Allow-Headers': '*',
        "Authorization": "aab03a624e33d9083d6c8531d2a321a8"
      });
  
  
      const cloneReq = httpRequest.clone({headers});
  
      return next.handle(cloneReq);
    return next.handle(httpRequest);
  }
}