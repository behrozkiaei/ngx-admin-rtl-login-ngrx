export enum Features {
  Posts = 'Posts',
}
