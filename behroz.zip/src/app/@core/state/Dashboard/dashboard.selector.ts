 
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from '../reducers';

import { DashboardState } from './dashboard.reducer';
export const selectFeatureDashboard = (state: State) => state.dashboard;
export const selectDashbord = createSelector(
    selectFeatureDashboard,
    (dashboard: DashboardState) => dashboard.dashboardData
  );

export const selectDashbordMerchantsCount = createSelector(
    selectFeatureDashboard,
    (dashboard: DashboardState) => dashboard.dashboardData?.merchantsCount
  );
  export const selectDashbordOperatorsCount = createSelector(
    selectFeatureDashboard,
    (dashboard: DashboardState) => dashboard.dashboardData?.operatorsCount
  );
  export const selectDashbordSuggestionsCount = createSelector(
    selectFeatureDashboard,
    (dashboard: DashboardState) => dashboard.dashboardData?.suggestionsCount
  );
  export const selectDashbordUsersCount = createSelector(
    selectFeatureDashboard,
    (dashboard: DashboardState) => dashboard.dashboardData?.usersCount
  );
  export const selectDashbordVersionCount = createSelector(
    selectFeatureDashboard,
    (dashboard: DashboardState) => dashboard.dashboardData?.versionCount
  );