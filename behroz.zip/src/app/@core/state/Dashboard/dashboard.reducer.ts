import { Action, createReducer, on } from '@ngrx/store';
import { Dashboard } from '../../models/dashboard.model';

import * as dashboardActions from './dashboard.actions';
// import { User } from '../models/user.model';
// import { userState } from './user.selectors';

export interface DashboardState {
  dashboardData: Dashboard,
  loading? :boolean,
  error? : string
}

const dashboardStartState : DashboardState ={
    dashboardData : null,
    loading : false,
    error: null
} 

export const dashboardInitialState: DashboardState =  JSON.parse(localStorage.getItem("dashboard")) || dashboardStartState ;


const reducer = createReducer(
   dashboardInitialState,
  on(dashboardActions.load, state => {
    return {
        ...state,
        loading: true,
        error: null
      }
  }),
  on(dashboardActions.loadSuccess, (state, { dashboardData }) => {
    console.log(dashboardData)
    return{
      ...state,
      loading: false,
      error: null,
      dashboardData: dashboardData,
    }
  }),
  on(dashboardActions.loadFailed,(state, {error} )=> ({
    ...state,
    loading: false,
    error : error
  })),
);

export function dashboardReducer(state: DashboardState | undefined, action: Action) {
  return reducer(state, action);
}
