import { createAction, props } from '@ngrx/store';
import { Dashboard } from '../../models/dashboard.model';

export const load = createAction(
  '[Dashboard] Start Load',
//   props<{ username: string; password: string }>(),
);

export const loadSuccess = createAction(
  '[Dashboard] Dashboard Load Success',
  props<{ dashboardData: Dashboard }>(),
);

export const loadFailed = createAction('[Dashboard] Dashboard Load Failed', props<{ error: string }>());

