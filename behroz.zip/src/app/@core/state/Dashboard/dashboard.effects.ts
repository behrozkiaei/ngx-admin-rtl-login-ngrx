import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, mergeMap, tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { CookieService } from 'ngx-cookie-service';

import { DashboardService } from '../../services/dashboard.service';
import { Dashboard } from '../../models/dashboard.model';
import * as dashboardActions from './dashboard.actions';
import * as dashboardSelectors from './dashboard.selector'
import { Action } from 'rxjs/internal/scheduler/Action';
import { from } from 'rxjs';
import {DashboardResponse} from "../../models/dashboard.model"
@Injectable()
export class dashboardEffects {

    load$ = createEffect(() =>
    this.actions$.pipe(
      ofType(dashboardActions.load),
      mergeMap(() =>
        this.dashboardService.getCount()
      ),
      catchError((err, caught$) => {
        console.log("err",err)
        this.store.dispatch(dashboardActions.loadFailed({error: err.message || "خطا در برقراری سرویس" }))
        return caught$;
      }),
      tap(data=>console.log("data",data)),
      map(data => dashboardActions.loadSuccess({ dashboardData : data.content })),
    ),
  );

  

  constructor(private actions$: Actions,
              private store: Store,
              private dashboardService: DashboardService,
              private cookieService: CookieService,
              private router: Router) {
  }
}
