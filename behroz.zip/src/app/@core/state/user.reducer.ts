import { Action, createReducer, on } from '@ngrx/store';

import * as userActions from './user.actions';
import { User } from '../models/user.model';
import { userState } from './user.selectors';

export interface UserState {
  entity: User;
  loggingIn: boolean;
  loading : boolean,
  error: string
}

const startState : UserState ={
  entity: undefined,
  loggingIn: false,
  loading : false,
  error: null
} 

export const userInitialState: UserState =  JSON.parse(localStorage.getItem("user")) || startState ;
console.log("userInitialState", userInitialState);

const reducer = createReducer(
  userInitialState,
  on(userActions.login, state => ({
    ...state,
    loggingIn: true,
  })),
  on(userActions.loginSuccess, (state, { user }) => ({
    ...state,
    entity: user,
    loggingIn: true,
  })),
  on(userActions.loginFailed, state => ({
    ...state,
    loggingIn: false,
  })),
  
  on(userActions.logout, () => ({
    ...startState,
  })),
  on(userActions.setUser, (state, { user }) => ({
    ...state,
    entity: user,
  })),
);

export function userReducer(state: UserState | undefined, action: Action) {
  return reducer(state, action);
}
