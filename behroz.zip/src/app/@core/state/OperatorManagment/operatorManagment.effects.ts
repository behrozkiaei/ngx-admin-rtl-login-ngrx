import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, mergeMap, tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { CookieService } from 'ngx-cookie-service';

import { OperatorManagmentService } from '../../services/operator-managment.service';

import * as operatorManagmentActions from './operatorManagment.actions';
import * as operatorManagmentSelectors from './operatorManagment.selector'
import { Action } from 'rxjs/internal/scheduler/Action';
import { from } from 'rxjs';
import {IResponseAPI} from "../../models/Response.interface"
import { fetchUserDataSuccess, registerUserSuccess, updateUserSuccess } from './operatorManagment.actions';
import { updateOperator } from '../../models/operatorManagment.interface';
@Injectable()
export class operatorManagmentEffects {

load$ = createEffect(() =>
this.actions$.pipe(
    ofType(operatorManagmentActions.load),
    mergeMap(() =>
      this.operatorManagmentService.getOperators()
    ),
    catchError((err, caught$) => {
      console.log("err",err)
      this.store.dispatch(operatorManagmentActions.loadFailed({error: err.message || "خطا در برقراری سرویس" }))
      return caught$;
    }),
    tap(data=>console.log("data",data)),
    map(data => operatorManagmentActions.loadSuccess({ operatorManagmentData : data?.content?.operators || null})),
),
);


registerUser$ = createEffect(() =>
this.actions$.pipe(
  ofType(operatorManagmentActions.registerUserStart),
  mergeMap((action ) =>{
  console.log(action)
   let {type , ...payload} = action;
    return this.operatorManagmentService.registerOperators(payload).pipe(
      map(data=>{
      if (data && data?.code == 0 && data.content){
        this.store.dispatch(registerUserSuccess({operator: data.content}))
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(operatorManagmentActions.loadFailed({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);


updateUser$ = createEffect(() =>
this.actions$.pipe(
  ofType(operatorManagmentActions.updateUserStart),
  mergeMap((action ) =>{
  console.log(action)
   
   let payload : updateOperator = {
    uniqueId: "",
    username:"",
    firstName:"",
    lastName:"",
    operatorRole:{id :0 , roleName: ""},
    enabled:false,
    roleId: 1,
    role: "" ,
    userId: "",
    operatorUniqueId:""
   }
    return this.operatorManagmentService.updateOperator(payload).pipe(
      map(data=>{
      if (data && data?.code == 0 && data.content){
        this.store.dispatch(updateUserSuccess({operator: data.content}))
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(operatorManagmentActions.updateFaild({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);
fetchUserData$ = createEffect(() =>
this.actions$.pipe(
  ofType(operatorManagmentActions.fetchUserDataStart),
  mergeMap((action ) =>{
    return this.operatorManagmentService.fetchUser(action.id).pipe(
      map(data=>{
      if (data && data?.code == 0 && data.content){
        this.store.dispatch(fetchUserDataSuccess({operator: data.content}))
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(operatorManagmentActions.loadFailed({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);

getRoles$ = createEffect(() =>
this.actions$.pipe(
  ofType(operatorManagmentActions.loadRolesStart),
  mergeMap(() =>
    this.operatorManagmentService.getRoles()
  ),
  catchError((err, caught$) => {
    console.log("err",err)
    this.store.dispatch(operatorManagmentActions.loadFailed({error: err.message || "خطا در برقراری سرویس" }))
    return caught$;
  }),
  tap(data=>console.log("data",data)),
  map(data => operatorManagmentActions.loadRolesSucess({ opearatorRoles : data.content})),
),
);
  constructor(private actions$: Actions,
              private store: Store,
              private operatorManagmentService: OperatorManagmentService,
              private cookieService: CookieService,
              private router: Router) {
  }
}
