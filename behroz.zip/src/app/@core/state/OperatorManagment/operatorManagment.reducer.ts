import { Action, createReducer, on } from '@ngrx/store';
import { opearatorRoles, operators, } from '../../models/operatorManagment.interface';

import * as operatorManagmentActions from './operatorManagment.actions';
// import { User } from '../models/user.model';
// import { userState } from './user.selectors';

export interface OperatorManagmentState {
  operatorManagmentData: operators[],
  loading? :boolean,
  error? : string,
  operatorsRole? : opearatorRoles[],
  fetchUserDataById? : operators
}

const operatorManagmentStartState : OperatorManagmentState ={
    operatorManagmentData : null,
    loading : false,
    error: null,
    operatorsRole : null,
    fetchUserDataById :null
} 

export const operatorManagmentInitialState: OperatorManagmentState =  operatorManagmentStartState ;


const reducer = createReducer(
   operatorManagmentInitialState,
  on(operatorManagmentActions.load, state => {
    return {
        ...state,
        loading: true,
        error: null
      }
  }),
  on(operatorManagmentActions.loadSuccess, (state, { operatorManagmentData }) => {

    return{
      ...state,
      loading: false,
      error: null,
      operatorManagmentData: operatorManagmentData,
    }
  }),
  on(operatorManagmentActions.loadFailed,(state, {error} )=> ({
    ...state,
    loading: false,
    error : error
  })),
  on(operatorManagmentActions.registerUserStart,(state, {registerPayload}) => {
    return{
      ...state,
      loading : true, 
      error:null
    }
  }),
  on(operatorManagmentActions.registerUserSuccess,(state, {operator}) => {  
    return{
      ...state,
      loading : false, 
      error:null,
      operatorManagmentData: operator ? [operator ,...state.operatorManagmentData] : state.operatorManagmentData
    }
  }),
  on(operatorManagmentActions.updateUserStart,(state, {registerPayload}) => {
    return{
      ...state,
      loading : true, 
      error:null
    }
  }),
  on(operatorManagmentActions.updateUserSuccess,(state, {operator}) => {  
    let indexOverride 
    let data =  state.operatorManagmentData
    //find the user to be update 
    state.operatorManagmentData.find((user,i)=>{
    
          if(user.uniqueId === operator.uniqueId){
            indexOverride = i;
          }
          return user;
    }); //end if finding user index for overwrite
    
    //overwrite a specific user that updatated
    data[indexOverride] = operator;
    return{
      ...state,
      loading : false, 
      error:null,
      operatorManagmentData:  data
    }
  }),
  on(operatorManagmentActions.loadRolesStart,(state) => {

    return{
      ...state,
      loading : false,
      error:null,
    }
  }),
  on(operatorManagmentActions.loadRolesSucess,(state,{opearatorRoles}) => {

    return{
      ...state,
      loading : false,
      error:null,
      operatorsRole : opearatorRoles
    }
  }),
  on(operatorManagmentActions.fetchUserDataStart,(state,{id}) => {

    return{
      ...state,
      loading : true,
      error:null,
    }
  }),
  on(operatorManagmentActions.fetchUserDataSuccess,(state,{operator}) => {
    return{
      ...state,
      error:null,
      loading:true,
      fetchUserDataById: operator
    }
  }),
  on(operatorManagmentActions.removeFetchedUser,(state) => {

    return{
      ...state,
    }
  }),
  on(operatorManagmentActions.deleteOperatorStart,(state) => {

    return{
      ...state,
    }
  }),
  on(operatorManagmentActions.deleteOperatorSuccess,(state,{operator}) => {

    //remove that user from data source
    let data =  state.operatorManagmentData.filter(user=> user.uniqueId === operator.uniqueId); //end if finding user index for overwrite
    return{
      ...state,
      operatorManagmentData : data

    }
  }),
);

export function operatorManagmentReducer(state: OperatorManagmentState | undefined, action: Action) {
  return reducer(state, action);
}
