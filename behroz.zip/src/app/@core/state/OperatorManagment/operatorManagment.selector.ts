 
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from '../reducers';

import { OperatorManagmentState } from './operatorManagment.reducer';
export const selectFeatureOperators= (state: State) => state.operatorManagment;
export const selectRoles = createSelector(
  selectFeatureOperators,
    (operatorManagment: OperatorManagmentState) => operatorManagment.operatorsRole
  );

export const selectOperators = createSelector(
selectFeatureOperators,
  (operatorManagment: OperatorManagmentState) => operatorManagment.operatorManagmentData
);
export const selectOperatorsLoading = createSelector(
  selectFeatureOperators,
    (operatorManagment: OperatorManagmentState) => operatorManagment.loading
  )
export const selectOperatorsError = createSelector(
  selectFeatureOperators,
    (operatorManagment: OperatorManagmentState) => operatorManagment.error
  )
  export const getFetchedUser = createSelector(
    selectFeatureOperators,
      (operatorManagment: OperatorManagmentState) => operatorManagment.fetchUserDataById
    )

    export const getRoles = createSelector(
      selectFeatureOperators,
        (operatorManagment: OperatorManagmentState) => operatorManagment.operatorsRole
      )