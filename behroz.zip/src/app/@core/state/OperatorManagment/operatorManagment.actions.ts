import { createAction, props } from '@ngrx/store';
import { opearatorRoles, operators, registerPayload, updateOperator } from '../../models/operatorManagment.interface';

export const load = createAction('[OperatorManagment] Start Load');
export const loadSuccess = createAction('[OperatorManagment] OperatorManagment Load Success',props<{ operatorManagmentData: operators[] }>(),);
export const loadFailed = createAction('[OperatorManagment] OperatorManagment Load Failed', props<{ error: string }>());

//register And Update 
export const registerUserStart = createAction('[OperatorManagment] OperatorManagment Register start', props<{  registerPayload: registerPayload}>());
export const registerUserSuccess = createAction('[OperatorManagment] OperatorManagment Register start', props<{  operator: operators}>());
export const registerFailed = createAction('[OperatorManagment] OperatorManagment Register start', props<{  error: string}>());

export const updateUserStart = createAction('[OperatorManagment] OperatorManagment Register start', props<{  registerPayload: updateOperator}>());
export const updateUserSuccess = createAction('[OperatorManagment] OperatorManagment update start', props<{  operator: operators}>());
export const updateFaild = createAction('[OperatorManagment] OperatorManagment update start', props<{ error: string }>());

//role 
export const loadRolesStart = createAction('[OperatorManagmentRoles] Start Load');
export const loadRolesSucess = createAction('[OperatorManagmentRoles]  Load success', props<{ opearatorRoles: opearatorRoles[] }>());
export const loadRolesFailed = createAction('[OperatorManagmentRoles]  Load Failed',props<{ error: string }>());


// Fetch a user Data by id 
export const fetchUserDataStart = createAction('[OperatorManagmentRoles] Start Fetch User', props<{ id: string}>());
export const fetchUserDataSuccess = createAction('[OperatorManagmentRoles]  Fetch User success', props<{ operator: operators}>());
export const removeFetchedUser = createAction('[OperatorManagmentRoles]  Fetch User success');

// Fetch a user Data by id  and delete from data source
export const deleteOperatorStart = createAction('[OperatorManagmentRoles] Start Fetch User', props<{ id: string}>());
export const deleteOperatorSuccess = createAction('[OperatorManagmentRoles]  Fetch User success', props<{ operator: operators}>());