import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from './reducers';

import { UserState } from './user.reducer';


export const selectFeatureUser  = (state: State) => state.user;

 
export const selectLoggingIn = createSelector(
  selectFeatureUser,
  (user: UserState) => user.loggingIn
);
 
export const selectUser = createSelector(
  selectFeatureUser,
  (user: UserState) => user.entity
);

export const userState = createSelector(
  selectFeatureUser,
  (user: UserState) => user
);