import { Injectable } from '@angular/core';
import { Router } from '@angular/router';

import { Actions, createEffect, ofType } from '@ngrx/effects';
import { catchError, map, mergeMap, tap } from 'rxjs/operators';
import { Store } from '@ngrx/store';
import { CookieService } from 'ngx-cookie-service';
import * as configServerActions from './configServer.actions';
import * as configServerSelectors from './configServer.selector'
import { Action } from 'rxjs/internal/scheduler/Action';
import { from } from 'rxjs';
import {IResponseAPI} from "../../models/Response.interface"
import { ConfigServerService } from '../../services/configServer.service';
import { registerApplicationStart, registerApplicationSuccess, registerCategorySuccess } from './configServer.actions';
import { type } from 'os';
import { ToastService } from '../../services/toast.service';

@Injectable()
export class configServerEffects {

  constructor(private actions$: Actions,
    private store: Store,
    private configServerService: ConfigServerService,
    private cookieService: CookieService,
    private toastService : ToastService,
    private router: Router) {
}


/* -------------------------------------------------------------------------- */
/*                             Application Effects                            */
/* -------------------------------------------------------------------------- */
load$ = createEffect(() =>
this.actions$.pipe(
    ofType(configServerActions.load),
    mergeMap(() =>{
      return   this.configServerService.getAllApplication().pipe(
        map(data=>{
        if (data && data?.responseCode == "OK" && data.responseBody){
          console.log(data)
          this.store.dispatch(configServerActions.loadSuccess({response: data.responseBody}))
        }
      })
      )
    }
    ),
    catchError((err, caught$) => {
      console.log("err",err)
      this.store.dispatch(configServerActions.loadFailed({error: err.message || "خطا در برقراری سرویس" }))
      return caught$;
    })
), { dispatch: false }
);


registerApplication$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.registerApplicationStart),
  mergeMap((action ) =>{
  console.log(action)
   let {type , ...payload} = action;
    return this.configServerService.addApplicationItem(payload).pipe(
      map(data=>{
      if (data && data?.responseCode == "OK" && data.responseBody){
        this.store.dispatch(registerApplicationSuccess({response : data.responseBody}))
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.loadFailed({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);


updateApplication$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.updateApplicationStart),
  mergeMap((actions ) =>{
    console.log(actions)
    let {type,...payload} = actions
    return this.configServerService.updateApplicationItem(payload).pipe(
      map(data=>{
        if (data && data?.responseCode == "OK" && data.responseBody){
        this.store.dispatch(configServerActions.updateApplicationSuccess({response: data.responseBody}))
      }else{
        
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.updateFaild({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);

deleteApplication$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.deleteApplicationStart),
  mergeMap((actions ) =>{
    console.log(actions)
    let {type,...payload} = actions
    return this.configServerService.deleteApplicationItem(payload.id).pipe(
      map(data=>{
        if (data && data?.responseCode == "OK" ){
        this.store.dispatch(configServerActions.deleteApplicationSuccess())
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.updateFaild({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);

updateApplicationSuccess$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.updateApplicationSuccess ,configServerActions.registerApplicationSuccess,configServerActions.deleteApplicationSuccess),
  map((actions) =>{
   return  this.store.dispatch(configServerActions.load())
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.updateFaild({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);

/* -------------------------------------------------------------------------- */
/*                             Category Effects                            */
/* -------------------------------------------------------------------------- */
loadCategories$ = createEffect(() =>
this.actions$.pipe(
    ofType(configServerActions.loadCategoryStart),
    mergeMap(() =>{
      return   this.configServerService.getAllCategories().pipe(
        map(data=>{
        if (data && data?.responseCode == "OK" && data.responseBody){
          this.store.dispatch(configServerActions.loadCategorySuccess({response: data.responseBody}))
        }
      })
      )
    }
    ),
    catchError((err, caught$) => {
      console.log("err",err)
      this.store.dispatch(configServerActions.loadFailed({error: err.message || "خطا در برقراری سرویس" }))
      return caught$;
    })
), { dispatch: false }
);

registerCategory$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.registerCategoryStart),
  mergeMap((action ) =>{
  console.log(action)
   let {type , ...payload} = action;
    return this.configServerService.addCategoryItem(payload).pipe(
      map(data=>{
      if (data && data?.responseCode == "OK" && data.responseBody){
        this.store.dispatch(registerCategorySuccess({response : data.responseBody}))
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.loadCategoryFailed({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);





updateCategory$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.updateCategoryStart),
  mergeMap((actions ) =>{
    console.log(actions)
    let {type,...payload} = actions
    return this.configServerService.updateCategoryItem(payload).pipe(
      map(data=>{
        if (data && data?.responseCode == "OK" ){
        this.store.dispatch(configServerActions.updateCategorySuccess({response: data.responseBody}))
      }else{
        this.store.dispatch(configServerActions.updateCategoryFaild({error: data.message  }))
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.updateCategoryFaild({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);





deleteCategory$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.deleteCategoryStart),
  mergeMap((actions ) =>{
    console.log(actions)
    let {type,...payload} = actions
    return this.configServerService.deleteCategoryItem(payload.id).pipe(
      map(data=>{
        if (data && data?.responseCode == "OK" ){
        this.store.dispatch(configServerActions.deleteCategorySuccess())
        }else{
          this.store.dispatch(configServerActions.loadCategoryFailed({error : data.message}))
        }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.updateCategoryFaild({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);

updateCategorySuccess$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.updateCategorySuccess ,configServerActions.registerCategorySuccess,configServerActions.deleteCategorySuccess),
  map((actions) =>{
   return  this.store.dispatch(configServerActions.loadCategoryStart())
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.updateFaild({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);

/* -------------------------------------------------------------------------- */
/*                             Property Effects                            */
/* -------------------------------------------------------------------------- */

loadPropertiesies$ = createEffect(() =>
this.actions$.pipe(
    ofType(configServerActions.loadPropertyStart),
    mergeMap(() =>{
      return   this.configServerService.getAllProperties().pipe(
        map(data=>{
        if (data && data?.responseCode == "OK" && data.responseBody){
          this.store.dispatch(configServerActions.loadPropertySuccess({response: data.responseBody}))
        }
      })
      )
    }
    ),
    catchError((err, caught$) => {
      console.log("err",err)
      this.store.dispatch(configServerActions.loadFailed({error: err.message || "خطا در برقراری سرویس" }))
      return caught$;
    })
    ), { dispatch: false }
    );

registerProperty$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.registerPropertyStart),
  mergeMap((action ) =>{
  console.log(action)
   let {type , ...payload} = action;
    return this.configServerService.addPropertyItem(payload).pipe(
      map(data=>{
      if (data && data?.responseCode == "OK" && data.responseBody){
        this.store.dispatch(configServerActions.registerPropertySuccess({response : data.responseBody}))
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.loadPropertyFailed({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);


updateProperty$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.updatePropertyStart),
  mergeMap((actions ) =>{
    console.log(actions)
    let {type,...payload} = actions
    return this.configServerService.updatePropertyItem(payload).pipe(
      map(data=>{
        if (data && data?.responseCode == "OK" && data.responseBody){
        this.store.dispatch(configServerActions.updatePropertySuccess({response: data.responseBody}))
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.updatePropertyFaild({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);
deleteProperty$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.deletePropertyStart),
  mergeMap((actions ) =>{
    console.log(actions)
    let {type,...payload} = actions
    console.log(payload)
    return this.configServerService.deletePropertyItem(payload.id).pipe(
      map(data=>{
        if (data && data?.responseCode == "OK" ){
        this.store.dispatch(configServerActions.deletePropertySuccess())
      }else{
        this.store.dispatch(configServerActions.loadPropertyFailed({error : data.message}))
      }
    })
    )
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.loadPropertyFailed({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);


updatePropertySuccess$ = createEffect(() =>
this.actions$.pipe(
  ofType(configServerActions.updatePropertySuccess ,configServerActions.registerPropertySuccess,configServerActions.deletePropertySuccess),
  map((actions) =>{
   return  this.store.dispatch(configServerActions.loadPropertyStart())
  }
  ),
  catchError((err, caught$) => {

    this.store.dispatch(configServerActions.updateFaild({error: err.message || "خطا در برقراری سرویس" }))
    // throw new Error(err.message)
    return caught$;
  }),

)
, { dispatch: false }
);




/* -------------------------------------------------------------------------- */
/*                             Assign Data Effects                            */
/* -------------------------------------------------------------------------- */
  assignAppToCategory$ = createEffect(() =>
    this.actions$.pipe(
        ofType(configServerActions.assignAppToCategoryStart),
        mergeMap((actions ) =>{
          console.log(actions)
          let {type,...payload} = actions
          return this.configServerService.assignAppToCategory(actions.payload).pipe(
            map(data=>{
              if (data && data?.responseCode == "OK" && data.responseBody){
                this.toastService.showToast("success","موفق", "عملیات  با موفقیت انجام شد")
                this.store.dispatch(configServerActions.assignAppToCategorySuccess({response: data.responseBody}))
            }else{
              this.store.dispatch(configServerActions.loadFailed({error:data.message || "خطا در برقراری سرویس"}))
            }
          })
          )
        }
        ),
        catchError((err, caught$) => {
          console.log("err",err)
          this.store.dispatch(configServerActions.loadFailed({error: "خطا در برقراری سرویس" }))
          return caught$;
        })
      ), { dispatch: false }
  );

assignCategoryToConfigProperty$ = createEffect(() =>
    this.actions$.pipe(
        ofType(configServerActions.assignCategoryToConfigPropertyStart),
        mergeMap((actions ) =>{
          console.log(actions)
          let {type,...payload} = actions
          return this.configServerService.assignCategoryToConfigProperty(payload.payload).pipe(
            map(data=>{
              if (data && data?.responseCode == "OK" && data.responseBody){
                this.toastService.showToast("success","موفق", "عملیات  با موفقیت انجام شد")
                this.store.dispatch(configServerActions.assignCategoryToConfigPropertySuccess({response: data.responseBody}))
            }else{
              this.store.dispatch(configServerActions.loadFailed({error:data.message || "خطا در برقراری سرویس"}))
            }
          })
          )
        }
        ),
        catchError((err, caught$) => {
          console.log("err",err)
          this.store.dispatch(configServerActions.loadFailed({error: "خطا در برقراری سرویس" }))
          return caught$;
        })
    ), { dispatch: false }
  );
}