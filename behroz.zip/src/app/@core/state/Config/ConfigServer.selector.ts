 
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { ConfigServerManagmentState } from '../../models/configServer.interface';
import { State } from '../reducers';

export const selectFeatureConfigServer= (state: State) => state.configServer;
export const ApplicationManagmentData = createSelector(
selectFeatureConfigServer,
  (configServerData: ConfigServerManagmentState) => configServerData.ApplicationManagmentData
);
export const CategoryManagmentData = createSelector(
  selectFeatureConfigServer,
    (configServerData: ConfigServerManagmentState) => configServerData.CategoryManagmentData
  );
export const PropertyManagmentData = createSelector(
  selectFeatureConfigServer,
    (configServerData: ConfigServerManagmentState) => configServerData.PropertyManagmentData
);

export const PropertyLoadingData = createSelector(
  selectFeatureConfigServer,
    (configServerData: ConfigServerManagmentState) => configServerData.Propertyloading
);

export const CategoryLoadingData = createSelector(
  selectFeatureConfigServer,
    (configServerData: ConfigServerManagmentState) => configServerData.Categoryloading
);

export const ApplicationLoadingData = createSelector(
  selectFeatureConfigServer,
    (configServerData: ConfigServerManagmentState) => configServerData.Applicationloading
);

export const PropertyErrorData = createSelector(
  selectFeatureConfigServer,
    (configServerData: ConfigServerManagmentState) => configServerData.Propertyerror
);

export const CategoryErrorData = createSelector(
  selectFeatureConfigServer,
    (configServerData: ConfigServerManagmentState) => configServerData.Categoryerror
);

export const ApplicationErrorData = createSelector(
  selectFeatureConfigServer,
    (configServerData: ConfigServerManagmentState) => configServerData.Applicationerror
);