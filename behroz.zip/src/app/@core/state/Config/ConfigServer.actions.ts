import { createAction, props } from '@ngrx/store';
import { Application, Category, Property } from '../../models/configServer.interface';
import { assignAppToCategory, assignCategoryToConfigProperty } from '../../models/dashboard.model';


/* -------------------------------------------------------------------------- */
/*                         apliacation CRUS managment Data  CRUD managment Dat                        */
/* -------------------------------------------------------------------------- */

export const load = createAction('[ConfigServer] Start Load');
export const loadSuccess = createAction('[ConfigServer] ConfigServer Load Success',props<{ response: Application[] }>());
export const loadFailed = createAction('[ConfigServer] ConfigServer Load Failed', props<{ error: string }>());

//register And Update 
export const registerApplicationStart = createAction('[ConfigServer] ConfigServer Register start', props<{  payload: Application}>());
export const registerApplicationSuccess = createAction('[ConfigServer] ConfigServer Register start', props<{  response: Application}>());
export const registerFailed = createAction('[ConfigServer] ConfigServer Register Failed', props<{  error: string}>());

export const updateApplicationStart = createAction('[ConfigServer] ConfigServer Application Update start', props<{  payload: Application}>());
export const updateApplicationSuccess = createAction('[ConfigServer] ConfigServer Application Update success', props<{  response: Application}>());
export const updateFaild = createAction('[ConfigServer] ConfigServer Application update Failed', props<{ error: string }>());


// Fetch a Application Data by id 
export const fetchApplicationDataStart = createAction('[ConfigServerRoles] Start Fetch Application', props<{ id: string}>());
export const fetchApplicationDataSuccess = createAction('[ConfigServerRoles]  Fetch Application success', props<{ response: Application}>());
export const removeFetchedApplication = createAction('[ConfigServerRoles]  Fetch Application success');

// Fetch a Application Data by id  and delete from data source
export const deleteApplicationStart = createAction('[ConfigServerRoles] delete Start  Application', props<{ id: string}>());
export const deleteApplicationSuccess = createAction('[ConfigServerRoles] delete   Application success');



/* -------------------------------------------------------------------------- */
/*                         Category CRUD managment Dat                        */
/* -------------------------------------------------------------------------- */

//Property CRUS managment Data 
export const loadCategoryStart = createAction('[ConfigServer] Start LoadCategory');
export const loadCategorySuccess = createAction('[ConfigServer] ConfigServer LoadCategory Success ',props<{ response: Category[] }>(),);
export const loadCategoryFailed = createAction('[ConfigServer] ConfigServer LoadCategory Failed', props<{ error: string }>());

//register Category And Update 
export const registerCategoryStart = createAction('[ConfigServer] ConfigServer RegisterCategory start', props<{  payload: Category}>());
export const registerCategorySuccess = createAction('[ConfigServer] ConfigServer RegisterCategory success', props<{  response: Category}>());
export const registerCategoryFailed = createAction('[ConfigServer] ConfigServer RegisterCategory Failed', props<{  error: string}>());

export const updateCategoryStart = createAction('[ConfigServer] ConfigServer updateCategory start', props<{  Payload: Category}>());
export const updateCategorySuccess = createAction('[ConfigServer] ConfigServer updateCategory success', props<{  response: Category}>());
export const updateCategoryFaild = createAction('[ConfigServer] ConfigServer updateCategory Failed', props<{ error: string }>());


// Fetch a Category Data by id 
export const fetchCategoryDataStart = createAction('[ConfigServerRoles] Start Fetch Application', props<{ id: string}>());
export const fetchCategoryDataSuccess = createAction('[ConfigServerRoles]  Fetch Application success', props<{ response: Category}>());
export const removeCategoryApplication = createAction('[ConfigServerRoles]  Fetch Application success');

// Fetch a Category Data by id  and delete from data source
export const deleteCategoryStart = createAction('[ConfigServerRoles] Start Delete Category', props<{ id: string}>());
export const deleteCategorySuccess = createAction('[ConfigServerRoles]  Fetch  delete Category success');
export const deleteCategoryFailed = createAction('[ConfigServerRoles]  Fetch delete Category ', props<{ error: string }>());


/* -------------------------------------------------------------------------- */
/*                         Property CRUD managment Dat                        */
/* -------------------------------------------------------------------------- */

export const loadPropertyStart = createAction('[ConfigServer] Start LoadProperty');
export const loadPropertySuccess = createAction('[ConfigServer] ConfigServer LoadProperty Success ',props<{ response: Property[] }>(),);
export const loadPropertyFailed = createAction('[ConfigServer] ConfigServer LoadProperty Failed', props<{ error: string }>());

//register Property And Update 
export const registerPropertyStart = createAction('[ConfigServer] ConfigServer RegisterProperty start', props<{  payload: Property}>());
export const registerPropertySuccess = createAction('[ConfigServer] ConfigServer RegisterProperty success', props<{  response: Property}>());
export const registerPropertyFailed = createAction('[ConfigServer] ConfigServer RegisterProperty Failed', props<{  error: string}>());

export const updatePropertyStart = createAction('[ConfigServer] ConfigServer RegisterProperty start', props<{  Payload: Property}>());
export const updatePropertySuccess = createAction('[ConfigServer] ConfigServer updateProperty success', props<{  response: Property}>());
export const updatePropertyFaild = createAction('[ConfigServer] ConfigServer updateProperty Failed', props<{ error: string }>());


// Fetch a Property Data by id 
export const fetchPropertyDataStart = createAction('[ConfigServerRoles] Start Fetch Application', props<{ id: string}>());
export const fetchPropertyDataSuccess = createAction('[ConfigServerRoles]  Fetch Application success', props<{ response: Property}>());
export const removePropertyApplication = createAction('[ConfigServerRoles]  Fetch Application success');

// Fetch a Property Data by id  and delete from data source
export const deletePropertyStart = createAction('[ConfigServerRoles] Start Fetch Application', props<{ id: string}>());
export const deletePropertySuccess = createAction('[ConfigServerRoles]  Fetch Application success');


/* -------------------------------------------------------------------------- */
/*                       assign Config managment managment Dat                */
/* -------------------------------------------------------------------------- */


export const assignAppToCategoryStart = createAction('[ConfigServerRoles] assignAppToCategory Start  ', props<{ payload: assignAppToCategory}>());
export const assignAppToCategorySuccess = createAction('[ConfigServerRoles]  assignAppToCategory  success', props<{ response: assignAppToCategory}>());

export const assignCategoryToConfigPropertyStart = createAction('[ConfigServerRoles] assignCategoryToConfigProperty Start  ', props<{ payload: assignCategoryToConfigProperty}>());
export const assignCategoryToConfigPropertySuccess = createAction('[ConfigServerRoles]  assignCategoryToConfigProperty  success', props<{ response: assignCategoryToConfigProperty}>());
