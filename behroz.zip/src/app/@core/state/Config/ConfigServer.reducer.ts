import { Action, createReducer, on } from '@ngrx/store';
import { Application, Category, ConfigServerManagmentState, Property } from '../../models/configServer.interface';


import * as ConfigServerManagmentActions from './ConfigServer.actions';
// import { User } from '../models/user.model';
// import { userState } from './user.selectors';


const ConfigServerManagmentStartState : ConfigServerManagmentState ={
  ApplicationManagmentData: [],
  CategoryManagmentData: [],
  PropertyManagmentData: [],
  Applicationloading :false,
  Categoryloading:false,
  Propertyloading:false,
  Applicationerror : null,
  Categoryerror : null,
  Propertyerror: null,
} 

export const ConfigServerManagmentInitialState: ConfigServerManagmentState =  ConfigServerManagmentStartState ;





const reducer = createReducer(
   ConfigServerManagmentInitialState,


/* -------------------------------------------------------------------------- */
/*                     Application Data Reducers Managment                    */
/* -------------------------------------------------------------------------- */

  on(ConfigServerManagmentActions.load, state => {
    return {
        ...state,
        Applicationloading: true,
        Applicationerror: null
      }
  }),
  on(ConfigServerManagmentActions.loadSuccess, (state, { response }) => {
  console.log(response)
    return{
      ...state,
      Applicationloading: false,
      Applicationerror: null,
      ApplicationManagmentData: response,
    }
  }),
  on(ConfigServerManagmentActions.loadFailed,(state, {error} )=> ({
    ...state,
    Applicationloading: false,
    Applicationerror : error
  })),
  on(ConfigServerManagmentActions.registerApplicationStart,(state, {payload}) => {
    return{
      ...state,
      Applicationloading : true, 
      Applicationerror:null
    }
  }),
  on(ConfigServerManagmentActions.registerApplicationSuccess,(state, {response}) => {  
    return{
      ...state,
      Applicationloading : false, 
      Applicationerror:null,
      ApplicationManagmentData: response ? [response ,...state.ApplicationManagmentData] : state.ApplicationManagmentData
    }
  }),
  on(ConfigServerManagmentActions.updateApplicationStart,(state, {payload}) => {
     console.log(payload)
    return{
      ...state,
      Applicationloading : true, 
      Applicationerror:null
    }
  }),
  on(ConfigServerManagmentActions.updateApplicationSuccess,(state, {response}) => {  

    return{
      ...state,
      loading : false, 
      Applicationerror:null,
    }
  }),



/* -------------------------------------------------------------------------- */
/*                     Category Data Reducers Managment                    */
/* -------------------------------------------------------------------------- */

  on(ConfigServerManagmentActions.loadCategoryStart,(state) => {

    return{
      ...state,
      Categoryloading : false,
      Categoryerror:null,
    }
  }),
  on(ConfigServerManagmentActions.loadCategorySuccess,(state,{response}) => {

    return{
      ...state,
      Categoryloading : false,
      Categoryerror:null,
      CategoryManagmentData : response
    }
  }),
  on(ConfigServerManagmentActions.loadCategoryFailed,(state,{error}) => {

    return{
      ...state,
      Categoryloading : false,
    }
  }),



/* -------------------------------------------------------------------------- */
/*                     Property Data Reducers Managment                    */
/* -------------------------------------------------------------------------- */
on(ConfigServerManagmentActions.loadPropertyStart,(state) => {

  return{
    ...state,
    Propertyloading : false,
    Propertyerror:null,
  }
}),
on(ConfigServerManagmentActions.loadPropertySuccess,(state,{response}) => {

  return{
    ...state,
    Propertyloading : false,
    Propertyerror:null,
    PropertyManagmentData : response
  }
}),
on(ConfigServerManagmentActions.loadPropertyFailed,(state,{error}) => {

  return{
    ...state,
    Propertyloading : false,
  }
})
);

export function ConfigServerManagmentReducer(state: ConfigServerManagmentState | undefined, action: Action) {
  return reducer(state, action);
}
