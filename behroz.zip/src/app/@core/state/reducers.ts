import { ActionReducerMap } from '@ngrx/store';
import { ConfigServerManagmentState } from '../models/configServer.interface';
import { ConfigServerManagmentReducer } from './Config/ConfigServer.reducer';
import { dashboardReducer, DashboardState } from './Dashboard/dashboard.reducer';
import { operatorManagmentReducer, OperatorManagmentState } from './OperatorManagment/operatorManagment.reducer';
import { userReducer, UserState } from "./user.reducer";

export interface State {
  user: UserState;
  dashboard: DashboardState;
  operatorManagment: OperatorManagmentState,
  configServer: ConfigServerManagmentState
}

export const reducers: ActionReducerMap<State> = {
  user: userReducer,
  dashboard: dashboardReducer,
  operatorManagment: operatorManagmentReducer,
  configServer: ConfigServerManagmentReducer,
};
