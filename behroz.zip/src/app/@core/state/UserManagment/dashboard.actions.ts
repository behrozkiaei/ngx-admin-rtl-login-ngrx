import { createAction, props } from '@ngrx/store';
import { User } from '../../models/user.model';

export const load = createAction(
  '[userManagment] Start Load',
//   props<{ username: string; password: string }>(),
);

export const loadSuccess = createAction(
  '[userManagment] userManagment Load Success',
  props<{ userManagmentData: User }>(),
);

export const loadFailed = createAction('[userManagment] userManagment Load Failed', props<{ error: string }>());

