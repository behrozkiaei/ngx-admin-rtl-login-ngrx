import { Action, createReducer, on } from '@ngrx/store';
import { userManagment } from '../../models/userManagment.model';

import * as userManagmentActions from './userManagment.actions';
// import { User } from '../models/user.model';
// import { userState } from './user.selectors';

export interface userManagmentState {
  userManagmentData: userManagment,
  loading? :boolean,
  error? : string
}

const userManagmentStartState : userManagmentState ={
    userManagmentData : null,
    loading : false,
    error: null
} 

export const userManagmentInitialState: userManagmentState =  JSON.parse(localStorage.getItem("userManagment")) || userManagmentStartState ;


const reducer = createReducer(
   userManagmentInitialState,
  on(userManagmentActions.load, state => {
    return {
        ...state,
        loading: true,
        error: null
      }
  }),
  on(userManagmentActions.loadSuccess, (state, { userManagmentData }) => {
    console.log(userManagmentData)
    return{
      ...state,
      loading: false,
      error: null,
      userManagmentData: userManagmentData,
    }
  }),
  on(userManagmentActions.loadFailed,(state, {error} )=> ({
    ...state,
    loading: false,
    error : error
  })),
);

export function userManagmentReducer(state: userManagmentState | undefined, action: Action) {
  return reducer(state, action);
}
