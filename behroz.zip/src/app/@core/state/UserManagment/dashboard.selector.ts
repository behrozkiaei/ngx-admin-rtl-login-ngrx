 
import { createFeatureSelector, createSelector } from '@ngrx/store';
import { State } from '../reducers';

import { userManagmentState } from './userManagment.reducer';
export const selectFeatureuserManagment = (state: State) => state.userManagment;
export const selectDashbord = createSelector(
    selectFeatureuserManagment,
    (userManagment: userManagmentState) => userManagment.userManagmentData
  );

export const selectDashbordMerchantsCount = createSelector(
    selectFeatureuserManagment,
    (userManagment: userManagmentState) => userManagment.userManagmentData?.merchantsCount
  );
  export const selectDashbordOperatorsCount = createSelector(
    selectFeatureuserManagment,
    (userManagment: userManagmentState) => userManagment.userManagmentData?.operatorsCount
  );
  export const selectDashbordSuggestionsCount = createSelector(
    selectFeatureuserManagment,
    (userManagment: userManagmentState) => userManagment.userManagmentData?.suggestionsCount
  );
  export const selectDashbordUsersCount = createSelector(
    selectFeatureuserManagment,
    (userManagment: userManagmentState) => userManagment.userManagmentData?.usersCount
  );
  export const selectDashbordVersionCount = createSelector(
    selectFeatureuserManagment,
    (userManagment: userManagmentState) => userManagment.userManagmentData?.versionCount
  );