import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { ApplicationComponent } from './application/application.component';
import { CategoryComponent } from './category/category.component';
import { PropertyComponent } from './property/property.component';

const routes: Routes = [{
  path: '',
  children: [
    {
      path: '',
      component: ApplicationComponent,
    },
    {
      path: 'application',
      component: ApplicationComponent,
    },
    {
      path: 'category',
      component: CategoryComponent
    },
    {
      path: 'property',
      component: PropertyComponent
    },
    {
      path: '**',
      component: ApplicationComponent,
    },
  ],
}];
@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class ConfigServerRoutingModule { }
