import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NbDialogRef } from '@nebular/theme';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { ApplicationComponent } from '../application.component';

@Component({
  selector: 'ngx-application-modal',
  templateUrl: './application-modal.component.html',
  styleUrls: ['./application-modal.component.scss']
})
export class ApplicationModalComponent implements OnInit {
  @Input() title;
  @Input() mode ;
  @Input() data ;
  fetchUserSubscribation : Subscription;
  ApplicationForm = new FormGroup({
    id: new FormControl('',[Validators.required]),
    name: new FormControl('',[Validators.required]),
    description: new FormControl('',[Validators.required]),
    
  });
  
  selectedRoled :string;
  constructor(protected dialogRef: NbDialogRef<ApplicationComponent>,private store : Store) { }
  ngOnInit(): void {
    if(this.mode == "update"){
      console.log("update operation")
    this.ApplicationForm.removeControl("id")
    this.data &&  this.ApplicationForm.setValue({
        name: this.data?.name || "",
        description: this.data?.description || "",
      });
   }
  }
  close() {
  }
  onSubmit(){

    if( this.ApplicationForm.valid){
      let data = this.ApplicationForm.value;
      data.id =  this.mode == "update" ? this.data.id :  data.id;
      this.dialogRef.close(this.ApplicationForm.value);
    }  
  }

  ngOnDestroy() {
    // this.fetchUserSubscribation.unsubscribe();

  }
}
