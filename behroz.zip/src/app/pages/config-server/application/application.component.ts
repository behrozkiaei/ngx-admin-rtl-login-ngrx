import { ChangeDetectorRef, Component, OnInit } from '@angular/core';
import { NbDialogService } from '@nebular/theme';
import { Store } from '@ngrx/store';
import { LocalDataSource } from 'ng2-smart-table';
import { Subject, Subscription } from 'rxjs';
import { ToastService } from '../../../@core/services/toast.service';
import * as configServerActions from '../../../@core/state/Config/ConfigServer.actions';
import * as congifgerverSelector from "../../../@core/state/Config/ConfigServer.selector"
import { ApplicationModalComponent } from './application-modal/application-modal.component';
@Component({
  selector: 'ngx-application',
  templateUrl: './application.component.html',
  styleUrls: ['./application.component.scss']
})
export class ApplicationComponent implements OnInit {
  data =  []
  editId = null;
  source: LocalDataSource = new LocalDataSource();
  selectApplication :Subscription ;
  ApplicationError :Subscription ;
  settings = {
    mode: 'external',
    add: {
      addButtonContent: '<i class="nb-plus" ></i>',
      createButtonContent: '<i class="nb-checkmark"  ></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmCreate: true,
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmSave  : true,
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      id: {
        title: 'ID',
        type: 'string',
      },
      name: {
        title: 'نام',
        type: 'string',
      },
      description: {
        title: 'توضیحات',
        type: 'string',
      }
    },
  };
  constructor(private store : Store,private toastService: ToastService,private dialogService : NbDialogService,private ref:ChangeDetectorRef) { }
 
  ngOnInit(): void {

    this.store.dispatch(configServerActions.load())
    this.ApplicationError= this.store.select(congifgerverSelector.ApplicationErrorData).pipe().subscribe(res=>{
      if(res){
        this.toastService.showToast("warning","خطا", res)
      }
    })
  
    this.selectApplication = this.store.select(congifgerverSelector.ApplicationManagmentData).pipe().subscribe(res=>{
      console.log(res)
      if(res){
        console.log(res)
        this.source.reset(true);
        this.source.load(res);
        this.ref.detectChanges();
      }
    })
  }


  onDestroy(){
    this.ApplicationError.unsubscribe();
    this.selectApplication.unsubscribe();
  }
  edit(event):void{
    this.editId = event.data.id;
    this.openAddEditDialog({mode : 'update',data : event.data})
  }
  create(event){
    console.log(event)
    this.openAddEditDialog({mode : 'create'})
  }
  delete(data){
    console.log(data)
    this.store.dispatch(configServerActions.deleteApplicationStart({id : data?.data?.id}))
  }

  openAddEditDialog(payload){

    this.dialogService.open(ApplicationModalComponent, {
      context: {
        title: 'مدیریت اپلیکیشن‌ها',
        mode : payload.mode,
        data : payload.data ? payload.data : null
      }, 
    }).onClose.subscribe(res=>{
      if(payload.mode == 'create' && res){
        let data = res;
        data.inProgress =false

        this.store.dispatch(configServerActions.registerApplicationStart(res))
      }
      if(payload.mode == 'update' && res){
        this.store.dispatch(configServerActions.updateApplicationStart(res))
      }
    });
  }
}