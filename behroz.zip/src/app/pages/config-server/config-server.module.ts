import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConfigServerRoutingModule } from './config-server-routing.module';
import { ApplicationComponent } from './application/application.component';
import { PropertyComponent } from './property/property.component';
import { CategoryComponent } from './category/category.component';
import { NbButtonModule, NbCardModule, NbCheckboxModule, NbInputModule, NbSelectModule } from '@nebular/theme';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { PropertyModalComponent } from './property/property-modal/property-modal.component';
import { CategoryModalComponent } from './category/category-modal/category-modal.component';
import { ApplicationModalComponent } from './application/application-modal/application-modal.component';
import { AssignAppToCategoryComponent } from './category/assign-app-to-category/assign-app-to-category.component';
import { AssignCategoryToConfigPropertyModalComponent } from './property/assign-category-to-config-property-modal/assign-category-to-config-property-modal.component';


@NgModule({
  declarations: [
    ApplicationComponent,
    PropertyComponent,
    CategoryComponent,
    PropertyModalComponent,
    CategoryModalComponent,
    ApplicationModalComponent,
    AssignAppToCategoryComponent,
    AssignCategoryToConfigPropertyModalComponent
  ],
  imports: [
    CommonModule,
    ConfigServerRoutingModule,
    NbCardModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    NbSelectModule,
    NbCheckboxModule,
    NbButtonModule,
    NbInputModule,
    Ng2SmartTableModule,
  ]
})
export class ConfigServerModule { }
