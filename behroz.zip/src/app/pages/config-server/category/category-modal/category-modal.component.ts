import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NbDialogRef } from '@nebular/theme';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { CategoryComponent } from '../category.component';

@Component({
  selector: 'ngx-category-modal',
  templateUrl: './category-modal.component.html',
  styleUrls: ['./category-modal.component.scss']
})
export class CategoryModalComponent implements OnInit {

  @Input() title;
  @Input() mode ;
  @Input() data ;
  CategoryForm = new FormGroup({
    id: new FormControl('',[Validators.required]),
    name: new FormControl('',[Validators.required]),
    description: new FormControl('',[Validators.required]),
  });
  
  selectedRoled :string;
  constructor(protected dialogRef: NbDialogRef<CategoryComponent>,private store : Store) { }
  ngOnInit(): void {
    if(this.mode == "update"){
      this.CategoryForm.removeControl("id")
        this.data &&  this.CategoryForm.setValue({
            name: this.data?.name || "",
            description: this.data?.description || "",
          });
    }
  }
  close() {
  }
  onSubmit(){
    console.log(this.CategoryForm.valid);
    if( this.CategoryForm.valid){
      let data = this.CategoryForm.value;
      data.id =  this.mode == "update" ? this.data.id :  data.id;
      this.dialogRef.close(data);
    }  
  }

  ngOnDestroy() {

  }
}
