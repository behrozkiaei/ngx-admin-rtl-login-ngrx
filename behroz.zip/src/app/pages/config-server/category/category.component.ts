import { Component, OnInit } from '@angular/core';
import { NbDialogService } from '@nebular/theme';
import { Store } from '@ngrx/store';
import { LocalDataSource } from 'ng2-smart-table';
import { Subscription } from 'rxjs';
import { threadId } from 'worker_threads';
import { ToastService } from '../../../@core/services/toast.service';
import * as configServerActions from '../../../@core/state/Config/ConfigServer.actions';
import * as congifgerverSelector from "../../../@core/state/Config/ConfigServer.selector"
import { AssignAppToCategoryComponent } from './assign-app-to-category/assign-app-to-category.component';
import { CategoryModalComponent } from './category-modal/category-modal.component';
import { assignAppToCategory, assignCategoryToConfigProperty } from '../../../@core/models/dashboard.model';
@Component({
  selector: 'ngx-category',
  templateUrl: './category.component.html',
  styleUrls: ['./category.component.scss']
})
export class CategoryComponent implements OnInit {

  data =  []
  editId :string;
  source: LocalDataSource = new LocalDataSource();
  selectCategory :Subscription ;
  CategoryError :Subscription ;
  settings = {
    mode: 'external',
   
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmSave  : true,
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    add: {
      addButtonContent: '<i class="nb-plus" ></i>',
      createButtonContent: '<i class="nb-checkmark"  ></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmCreate: true,
    },
    actions:{
      custom: [{ name: 'assignAppToCategoryAction', title: '<i class="nb-compose"></i>' }],
      add:true,
      delete:true,
      edit:true,
    },
    columns: {
      id: {
        title: 'ID',
        type: 'string',
      },
      name: {
        title: 'نام',
        type: 'string',
      },
      description: {
        title: 'توضیحات',
        type: 'string',
      }
    },
  };
  constructor(private store : Store,private toastService: ToastService,private dialogService : NbDialogService) { }
 
  ngOnInit(): void {

    this.store.dispatch(configServerActions.loadCategoryStart())
    this.CategoryError= this.store.select(congifgerverSelector.CategoryErrorData).pipe().subscribe(res=>{
      if(res){
        this.toastService.showToast("warning","خطا", res)
      }
    })
  
    this.selectCategory = this.store.select(congifgerverSelector.CategoryManagmentData).pipe().subscribe(res=>{
      if(res){
        console.log(res)
        this.source.load(res);
      }
    })
  }
  edit(event):void{
    console.log(event)
    this.editId = event.data.id;
    this.openAddEditDialog({mode : 'update',data : event.data})
  }
  create(event){
    console.log(event)
    this.openAddEditDialog({mode : 'create'})
  }
  delete(data){
    console.log(data)
    this.store.dispatch(configServerActions.deleteCategoryStart({id : data?.data?.id}))
  }
  onCustomAction(e){
    console.log(e)
    switch(e.action){
      case "assignAppToCategoryAction":
        this.openAssignAppToCategoryDialog(e.data)
    }
      
  }

 
  openAddEditDialog(payload){

    this.dialogService.open(CategoryModalComponent, {
      context: {
        title: 'مدیریت دسته ها',
        mode : payload.mode,
        data : payload.data ? payload.data : null
      }, 
    }).onClose.subscribe(res=>{
      if(payload.mode == 'create'){
        this.store.dispatch(configServerActions.registerCategoryStart(res))
      }
      if(payload.mode == 'update'){
        this.store.dispatch(configServerActions.updateCategoryStart(res))
      }
    });
  }

  openAssignAppToCategoryDialog(payload){
    this.dialogService.open(AssignAppToCategoryComponent, {
      context: {
        title: 'مدیریت دسته ها',
        mode : payload.mode,
        data : payload.data ? payload.data : null
      }, 
    }).onClose.subscribe(res=>{
      console.log(res)
      let assignData :assignAppToCategory  ={
        appId: res.appId,
        categoryId: payload?.id 
      }
      this.store.dispatch(configServerActions.assignAppToCategoryStart({ payload : assignData}))
  });
  }
}
