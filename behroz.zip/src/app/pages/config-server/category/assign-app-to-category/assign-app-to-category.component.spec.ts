import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignAppToCategoryComponent } from './assign-app-to-category.component';

describe('AssignAppToCategoryComponent', () => {
  let component: AssignAppToCategoryComponent;
  let fixture: ComponentFixture<AssignAppToCategoryComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignAppToCategoryComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignAppToCategoryComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
