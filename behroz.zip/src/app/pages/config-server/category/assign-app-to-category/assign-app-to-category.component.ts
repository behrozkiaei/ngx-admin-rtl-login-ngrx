import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { NbDialogRef } from '@nebular/theme';
import { Store } from '@ngrx/store';
import { CategoryComponent } from '../category.component';
import * as congifgerverSelector from "../../../../@core/state/Config/ConfigServer.selector"
import * as configServerActions from '../../../../@core/state/Config/ConfigServer.actions';
@Component({
  selector: 'ngx-assign-app-to-category',
  templateUrl: './assign-app-to-category.component.html',
  styleUrls: ['./assign-app-to-category.component.scss']
})
export class AssignAppToCategoryComponent implements OnInit {

  
  @Input() title;
  @Input() mode ;
  @Input() data ;
  CategoryForm = new FormGroup({
    appId: new FormControl('',[Validators.required]),
  });
  allApps$ = this.store.select(congifgerverSelector.ApplicationManagmentData);
  constructor(protected dialogRef: NbDialogRef<CategoryComponent>,private store : Store) { }
  ngOnInit(): void {
    this.store.select(congifgerverSelector.ApplicationManagmentData).subscribe(res=>{
      if(res.length==0){
        this.store.dispatch(configServerActions.load())
      }
    })
  }
  close() {
  }
  onSubmit(){
    console.log(this.CategoryForm.valid);
    if( this.CategoryForm.valid){
      let data = this.CategoryForm.value;
      this.dialogRef.close(data);
    }  
  }

  ngOnDestroy() {

  }

}
