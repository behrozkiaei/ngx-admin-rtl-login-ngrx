import { Component, Input, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import * as congifgerverSelector from "../../../../@core/state/Config/ConfigServer.selector"
import * as configServerActions from '../../../../@core/state/Config/ConfigServer.actions';
import { NbDialogRef } from '@nebular/theme';
import { Store } from '@ngrx/store';
import { PropertyComponent } from '../property.component';
@Component({
  selector: 'ngx-assign-category-to-config-property-modal',
  templateUrl: './assign-category-to-config-property-modal.component.html',
  styleUrls: ['./assign-category-to-config-property-modal.component.scss']
})
export class AssignCategoryToConfigPropertyModalComponent implements OnInit {

  @Input() title;
  @Input() mode ;
  @Input() data ;
  CategoryForm = new FormGroup({
    categoryId: new FormControl('',[Validators.required]),
  });
  allCategories$ = this.store.select(congifgerverSelector.CategoryManagmentData);
  constructor(protected dialogRef: NbDialogRef<PropertyComponent>,private store : Store) { }
  ngOnInit(): void {
    this.store.select(congifgerverSelector.CategoryManagmentData).subscribe(res=>{
      if(res.length==0){
        this.store.dispatch(configServerActions.loadCategoryStart())
      }
    })
  }
  close() {
  }
  onSubmit(){
    console.log(this.CategoryForm.valid);
    if( this.CategoryForm.valid){
      let data = this.CategoryForm.value;
      this.dialogRef.close(data);
    }  
  }

  ngOnDestroy() {

  }
}
