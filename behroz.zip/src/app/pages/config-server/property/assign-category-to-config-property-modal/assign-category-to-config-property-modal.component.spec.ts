import { ComponentFixture, TestBed } from '@angular/core/testing';

import { AssignCategoryToConfigPropertyModalComponent } from './assign-category-to-config-property-modal.component';

describe('AssignCategoryToConfigPropertyModalComponent', () => {
  let component: AssignCategoryToConfigPropertyModalComponent;
  let fixture: ComponentFixture<AssignCategoryToConfigPropertyModalComponent>;

  beforeEach(async () => {
    await TestBed.configureTestingModule({
      declarations: [ AssignCategoryToConfigPropertyModalComponent ]
    })
    .compileComponents();
  });

  beforeEach(() => {
    fixture = TestBed.createComponent(AssignCategoryToConfigPropertyModalComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
