import { Component, OnInit } from '@angular/core';
import { NbDialogService } from '@nebular/theme';
import { Store } from '@ngrx/store';
import { LocalDataSource } from 'ng2-smart-table';
import { Subscription } from 'rxjs';
import { assignCategoryToConfigProperty } from '../../../@core/models/dashboard.model';
import { ToastService } from '../../../@core/services/toast.service';
import * as configServerActions from '../../../@core/state/Config/ConfigServer.actions';
import * as congifgerverSelector from "../../../@core/state/Config/ConfigServer.selector"
import { AssignCategoryToConfigPropertyModalComponent } from './assign-category-to-config-property-modal/assign-category-to-config-property-modal.component';
import { PropertyModalComponent } from './property-modal/property-modal.component';
@Component({
  selector: 'ngx-property',
  templateUrl: './property.component.html',
  styleUrls: ['./property.component.scss']
})
export class PropertyComponent implements OnInit {

  data =  []
  editId :string;
  source: LocalDataSource = new LocalDataSource();
  selectProperty :Subscription ;
  PropertyError :Subscription ;
  settings = {
    mode: 'external',
    add: {
      addButtonContent: '<i class="nb-plus" ></i>',
      createButtonContent: '<i class="nb-checkmark"  ></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmCreate: true,
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmSave  : true,
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    actions:{
      custom: [{ name: 'AssignCategoryToConfigProperty', title: '<i class="nb-compose"></i>' }],
      add:true,
      delete:true,
      edit:true,
    },
    columns: {
      id: {
        title: 'ID',
        type: 'string',
      },
      key: {
        title: 'کلید',
        type: 'string',
      },
      value: {
        title: 'مقدار',
        type: 'string',
      },
      type: {
        title: 'نوع',
        type: 'string',
      },
      regex: {
        title: 'regex',
        type: 'string',
      }
      ,
      description: {
        title: 'توضیحات',
        type: 'string',
      }
      
    },
  };
  constructor(private store : Store,private toastService: ToastService,private dialogService: NbDialogService) { }
 
  ngOnInit(): void {

    this.store.dispatch(configServerActions.loadPropertyStart())
    this.PropertyError= this.store.select(congifgerverSelector.PropertyErrorData).pipe().subscribe(res=>{
      if(res){
        this.toastService.showToast("warning","خطا", res)
      }
    })
  
    this.selectProperty = this.store.select(congifgerverSelector.PropertyManagmentData).pipe().subscribe(res=>{
      if(res){
        console.log(res)
        this.source.load(res);
      }
    })
  }

  edit(event):void{
    this.editId = event.data.id;
    this.openAddEditDialog({mode : 'update',data : event.data})
  }
  create(event){
    console.log(event)
    this.openAddEditDialog({mode : 'create'})
  }
  onDestroy(){
    this.PropertyError.unsubscribe();
    this.selectProperty.unsubscribe();
  }
  delete(data){
    console.log(data)
    this.store.dispatch(configServerActions.deletePropertyStart({id : data?.data?.id}))
  }

  openAddEditDialog(payload){

    this.dialogService.open(PropertyModalComponent, {
      context: {
        title: 'مدیریت پراپرتی ها',
        mode : payload.mode,
        data : payload.data ? payload.data : null
      }, 
    }).onClose.subscribe(res=>{
      if(payload.mode == 'create'){
        this.store.dispatch(configServerActions.registerPropertyStart(res))
      }
      if(payload.mode == 'update'){
        this.store.dispatch(configServerActions.updatePropertyStart(res))
      }
    });
  }
  onCustomAction(e){
    console.log(e)
    switch(e.action){
      case "AssignCategoryToConfigProperty":
        this.assignCategoryToConfigProperty(e.data)
    }
      
  }

  assignCategoryToConfigProperty(payload){
    this.dialogService.open(AssignCategoryToConfigPropertyModalComponent, {
      context: {
        title: 'مدیریت دسته ها',
        mode : payload.mode,
        data : payload.data ? payload.data : null
      }, 
    }).onClose.subscribe(res=>{
      console.log(res)
      let assignData :assignCategoryToConfigProperty  = {
        categoryId:  res.categoryId,
        configPropertyId: payload?.id 
      }
      this.store.dispatch(configServerActions.assignCategoryToConfigPropertyStart({ payload : assignData}))
  });
  }


}
