import { Component, Input, OnInit } from '@angular/core';
import { AbstractControl, FormControl, FormGroup, ValidationErrors, ValidatorFn, Validators } from '@angular/forms';
import { NbDialogRef } from '@nebular/theme';
import { Store } from '@ngrx/store';
import { Subscription } from 'rxjs';
import { getFetchedUser } from '../../../../@core/state/OperatorManagment/operatorManagment.selector';
import { PropertyComponent } from '../property.component';

@Component({
  selector: 'ngx-property-modal',
  templateUrl: './property-modal.component.html',
  styleUrls: ['./property-modal.component.scss']
})
export class PropertyModalComponent implements OnInit {

  @Input() title;
  @Input() mode ;
  @Input() data ;
  fetchUserSubscribation : Subscription;
  PropertyForm = new FormGroup({
    id: new FormControl('',[Validators.required]),
    value: new FormControl('',[Validators.required]),
    type: new FormControl('',[Validators.required]),
    key: new FormControl('',[Validators.required]),
    regex: new FormControl('',[Validators.required]),
    description: new FormControl('',[Validators.required]),
    
  });
  
  selectedRoled :string;
  constructor(protected dialogRef: NbDialogRef<PropertyComponent>,private store : Store) { }
  ngOnInit(): void {
    if(this.mode == "update"){
      this.PropertyForm.removeControl("id")
        console.log(this.data)
        this.data &&  this.PropertyForm.setValue({
            value: this.data?.value || "",
            type: this.data?.type || "",
            regex: this.data?.regex || "",
            key  : this.data?.key || "",
            description: this.data?.description || "",
          }); 
    } // end if(this.mode == "update")
  }
  close() {
  }
  onSubmit(){
    console.log(this.PropertyForm.valid);
    if( this.PropertyForm.valid){
      let data = this.PropertyForm.value;
      data.typeMaster = data.type;
      console.log(data)
      data.id =  this.mode == "update" ? this.data.id :  data.id;
      this.dialogRef.close(data);
    }  
  }

  ngOnDestroy() {
    // this.fetchUserSubscribation.unsubscribe();
  }

  

}
