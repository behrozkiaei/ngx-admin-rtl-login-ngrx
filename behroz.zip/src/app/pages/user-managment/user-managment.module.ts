import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { UserManagmentComponent } from './user-managment/user-managment.component';
import { UserManagment } from './user-managment-routing.module';
import { NbButtonModule, NbCardModule, NbCheckboxModule, NbIconModule, NbInputModule, NbSelectModule, NbToastrService, NbTreeGridModule } from '@nebular/theme';
import { Ng2SmartTableModule } from 'ng2-smart-table';
import { AddEditModalComponent } from './add-edit-modal/add-edit-modal.component';
import { FormBuilder, FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MaterialModule } from '../../@core/shared/material/material.module';
import { NgxJDatePickerModule } from 'ngx-jdatepicker';
import { RolePermissionComponent } from './role-permission/role-permission.component';

@NgModule({
  declarations: [
    UserManagmentComponent,
    AddEditModalComponent,
    RolePermissionComponent,
    
  ],
  imports: [
    NbCardModule,
    FormsModule,
    ReactiveFormsModule,
    CommonModule,
    NbSelectModule,
    NbCheckboxModule,
    NbButtonModule,
    NbInputModule,
    Ng2SmartTableModule,
    UserManagment,
    NgxJDatePickerModule,
    MaterialModule,
    ],
  providers: [FormBuilder]
})
export class UserManagmentModule { }
