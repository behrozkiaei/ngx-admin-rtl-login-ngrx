import { ThisReceiver, ThrowStmt } from '@angular/compiler';
import { Component, OnInit, ViewChild } from '@angular/core';
import { NbDialogService } from '@nebular/theme';
import { Store } from '@ngrx/store';
import { LocalDataSource } from 'ng2-smart-table';
import { Observable, Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs-compat/operator/takeUntil';
import { SmartTableData } from '../../../@core/data/smart-table';
import { ToastService } from '../../../@core/services/toast.service';
import * as operatorManagmentActions from "../../../@core/state/OperatorManagment/operatorManagment.actions"
import { fetchUserDataStart, registerUserStart } from '../../../@core/state/OperatorManagment/operatorManagment.actions';
import * as operatorSelector from "../../../@core/state/OperatorManagment/operatorManagment.selector"
import { AddEditModalComponent } from '../add-edit-modal/add-edit-modal.component';
import { DatePickerComponent, IDatePickerConfig } from 'ngx-jdatepicker';
import * as moment from "jalali-moment";

@Component({
  selector: 'ngx-user-managment',
  templateUrl: './user-managment.component.html',
  styleUrls: ['./user-managment.component.scss']
})

export class UserManagmentComponent implements OnInit {
  data =  []
  source: LocalDataSource = new LocalDataSource();
  destroyNotifier = new Subject()
  selectOperatorsErrorSubscripation :Subscription ;
  selectOperatorsSubscripation :Subscription;
  @ViewChild('dayPicker') datePicker: DatePickerComponent;
  datePickerConfig : IDatePickerConfig= {
    drops: "down",
    format: "YY/M/D"
  };

  //OR if you have initial value you could use following code

  dateObject = moment("1400-11-22", "jYYYY,jMM,jDD");
  constructor(private dialogService: NbDialogService,
    private store: Store,
    private toastService: ToastService) {

  }
  settings = {
    mode: 'external',
    add: {
      addButtonContent: '<i class="nb-plus" ></i>',
      createButtonContent: '<i class="nb-checkmark"  ></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmCreate: true,
    },
    edit: {
      editButtonContent: '<i class="nb-edit"></i>',
      saveButtonContent: '<i class="nb-checkmark"></i>',
      cancelButtonContent: '<i class="nb-close"></i>',
      confirmSave  : true,
    },
    delete: {
      deleteButtonContent: '<i class="nb-trash"></i>',
      confirmDelete: true,
    },
    columns: {
      firstName: {
        title: 'نام',
        type: 'string',
      },
      lastName: {
        title: 'نام خانوادگی',
        type: 'string',
      },
      username: {
        title: 'نام کاربری',
        type: 'string',
      },
      enabled: {
        title: 'وضعیت',
        type: 'number',
        editor: {
          type: 'list',
          config: {
            placeholder: 'وضعیت',
            selectText: 'فعال/غیر فعال',
            list: [{ value: true, title: 'فعال' }, { value: false, title: 'غیر فعال' }]
          }
        },
        valuePrepareFunction: (value) => { 
          if(value == true) {
            return 'فعال'  
          }else{
            return 'غیرفعال'
          }
        }
      },
    },
  };

  
  ngOnInit(): void {

    this.store.dispatch(operatorManagmentActions.load())
    this.selectOperatorsErrorSubscripation = this.store.select(operatorSelector.selectOperatorsError).pipe().subscribe(res=>{
      if(res){
        this.toastService.showToast("warning","خطا", res)
      }
    })
  
    this.selectOperatorsSubscripation = this.store.select(operatorSelector.selectOperators).pipe().subscribe(res=>{
      if(res){
        console.log(res)
        this.source.load(res);
      }
    })
  }

  onDeleteConfirm(event): void {
    if (window.confirm('Are you sure you want to delete?')) {
      event.confirm.resolve();
    } else {
      event.confirm.reject();
    }
  }
  edit(event):void{
    console.log(event)
    // this.openAddEditDialog("edit")

    console.log(event.data.uniqueId)
    this.store.dispatch(fetchUserDataStart({id :event.data.uniqueId}))
    this.openAddEditDialog('update')
  }
  onCreateConfirm(event){
    this.openAddEditDialog() 
  }
  openAddEditDialog(mode = 'create'){

    this.dialogService.open(AddEditModalComponent, {
      context: {
        title: 'ثبت اپراتور جدید',
        mode : mode
      },
    }).onClose.subscribe(res=>{
      console.log("dflksdjlkajskdlfjlskjfldsajflkasd")
      this.store.dispatch(registerUserStart(res))
    });
  }
  onDestroy(){
    this.selectOperatorsErrorSubscripation.unsubscribe();
    this.selectOperatorsSubscripation.unsubscribe();
  }


  open() {
    this.datePicker.api.open();
  }
  
  close() {
       this.datePicker.api.close();
  }
  dateChanged(e){
    console.log(e)
  }
}
