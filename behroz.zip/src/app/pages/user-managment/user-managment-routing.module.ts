import { RouterModule, Routes } from '@angular/router';
import { NgModule } from '@angular/core';
import { UserManagmentComponent } from './user-managment/user-managment.component';
import { RolePermissionComponent } from './role-permission/role-permission.component';

const routes: Routes = [ 

  {
  path: '',
  component: UserManagmentComponent,
  },
  {
  path: 'role',
  component: RolePermissionComponent
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule],
})
export class UserManagment {
}
