import { Component, Input, OnInit } from '@angular/core';
import { NbDialogRef } from '@nebular/theme';
import { UserManagmentComponent } from '../user-managment/user-managment.component';
import { FormGroup, FormControl, Validators, ValidatorFn, AbstractControl, ValidationErrors } from '@angular/forms';
import { FormBuilder } from '@angular/forms';
import { Store } from '@ngrx/store';
import { registerUserStart ,updateUserStart } from '../../../@core/state/OperatorManagment/operatorManagment.actions';
import { getFetchedUser, getRoles } from '../../../@core/state/OperatorManagment/operatorManagment.selector';
import { Subject, Subscription } from 'rxjs';
import { takeUntil } from 'rxjs-compat/operator/takeUntil';
@Component({
  selector: 'ngx-add-edit-modal',
  templateUrl: './add-edit-modal.component.html',
  styleUrls: ['./add-edit-modal.component.scss']
})
export class AddEditModalComponent implements OnInit {

  @Input() title;
  @Input() mode ;
  fetchUserSubscribation : Subscription;
  operatorForm = new FormGroup({
    firstName: new FormControl('',[Validators.required]),
    lastName: new FormControl('',[Validators.required]),
    username: new FormControl('',[Validators.required]),
    password: new FormControl('',[Validators.required]),
    rePass: new FormControl('',[Validators.required]),
    roleId: new FormControl('',[Validators.required]),
  });
  Roles$ = this.store.select(getRoles);
  selectedRoled :string;
  constructor(protected dialogRef: NbDialogRef<UserManagmentComponent>,private store : Store) { }
  ngOnInit(): void {
    console.log(this.mode)
    this.operatorForm.setValidators(this.checkPasswords)
    
    if(this.mode == "update"){
      this.operatorForm.removeControl("password")
      this.operatorForm.removeControl("rePass")
      this.fetchUserSubscribation =  this.store.select(getFetchedUser)

     .subscribe(res=>{
          res &&  this.operatorForm.setValue({
            firstName: res?.firstName, 
            lastName: res?.lastName,
            username :res?.username,
            roleId: res?.operatorRole?.id
          });
          this.selectedRoled = res?.operatorRole?.id.toString()
        })
      }
  }
  close() {
  }
  onSubmit(){
    console.log(this.operatorForm.valid);
    if( this.operatorForm.valid){
  
      this.dialogRef.close(this.operatorForm.value);
    }  
  }

  checkPasswords: ValidatorFn = (group: AbstractControl):  ValidationErrors | null => { 
    if(group.get('password')){

      let pass = group.get('password').value;
      let confirmPass = group.get('rePass').value
      return pass === confirmPass ? null : { notSame: true }
    }else{
      return null;
    }
  }
  ngOnDestroy() {
    this.fetchUserSubscribation.unsubscribe();

  }

}
