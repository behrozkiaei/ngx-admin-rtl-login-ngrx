import { NbMenuItem } from '@nebular/theme';

export const MENU_ITEMS: NbMenuItem[] = [
  // {
  //   title: 'E-commerce',
  //   icon: 'shopping-cart-outline',
  //   link: '/pages/dashboard',
  //   home: true,
  // },
  {
    title: ' داشبورد ',
    icon: 'home-outline',
    link: '/pages/iot-dashboard',
  },
  {
    title: ' مدیریت کاربران ',
    icon: 'person-outline',
    link: '/pages/user-managment',
  },
  {
    title: ' پیکربندی ' ,
    icon: 'layout-outline',
    children: [
      {
        title: ' نرم افزار ها ',
        link: '/pages/config-server',
      },
      {
        title: ' دسته بندی ها ',
        link: '/pages/config-server/category',
      },
      {
        title: ' ویژگی ها ',
        link: '/pages/config-server/property',
      },
    ],
  },
  // {
  //   title: 'پیکربندی',
  //   group: true,
  // },
  {
    title: ' عملیات سیستمی ' ,
    icon: 'layout-outline',
    children: [
      {
        title: ' پذیرنده ها ',
        link: '/pages/layout/stepper',
      },
      {
        title: ' مدیریت بانک ها ',
        link: '/pages/layout/list',
      },
      {
        title: ' مدیریت ارائه دهنده ها ',
        link: '/pages/layout/infinite-list',
      },
      {
        title: ' مدیریت نسخه ها',
        link: '/pages/layout/infinite-list',
      },
      {
        title: ' مشاهده پاسخ های سرور',
        link: '/pages/layout/infinite-list',
      },
      {
        title: ' مشاهده فالوآپ ها',
        link: '/pages/layout/infinite-list',
      },
      {
        title: ' لغات ممنوعه',
        link: '/pages/layout/infinite-list',
      },
      {
        title: ' تنظیمات سرویس',
        link: '/pages/layout/infinite-list',
        children: [
          {
            title: 'مدیریت داشبورد سرویس',
            link: '/pages/layout/infinite-list',
          },
        ]
      },
    ],
  },

   {
    title: 'بیمه',
    group: true,
  },
  {
    title: ' مدیریت بیمه ',
    icon: 'checkmark-square-outline',
    children: [
      {
        title: 'مدیریت بیمه های شخص ثالث ',
        link: '/pages/forms/inputs',
      },
      {
        title: 'مدیریت اقساط بیمه ',
        link: '/pages/forms/inputs',
      },
      {
        title: 'مدیریت کمپین ',
        link: '/pages/forms/inputs',
      },
      {
        title: ' مدیریت کمپین هدایا',
        link: '/pages/forms/inputs',
      },
      {
        title: ' لیست سیاه',
        link: '/pages/forms/inputs',
      },
      {
        title: 'لیست سفید ',
        link: '/pages/forms/inputs',
      },
      {
        title: 'مدیریت کاربران واجد اعتبار ',
        link: '/pages/forms/inputs',
      },
      {
        title: 'واریز وجه به حساب مشتری ',
        link: '/pages/forms/inputs',
      },
      {
        title: 'اپراتورهای موبایل ',
        link: '/pages/forms/inputs',
      },
    ]
  },
  {
    title: ' جشنواره ',
    icon: 'checkmark-square-outline',
    children: [
      {
        title: 'مدیریت جشنواره ',
        link: '/pages/forms/inputs',
      },
      {
        title: 'مدیریت کدهای قرعه کشی ',
        link: '/pages/forms/inputs',
      },
      {
        title: 'لیست اهداف ',
        link: '/pages/forms/inputs',
      },
       {
        title: 'لیست کاربران مشکوک ',
        link: '/pages/forms/inputs',
      }
    ]
  },
  {
    title: 'گزارشات',
    group: true,
  },
  {
    title: ' گزارش مشتریان ' ,
    link: '/pages/forms/inputs',
  },
  {
    title: ' درخواست ها ',
    icon: 'checkmark-square-outline',
    children: [
      {
        title: ' انتقال کارت به کارت ',
        link: '/pages/forms/inputs',
      },
      {
        title: ' همه درخواست ها ',
        link: '/pages/forms/inputs',
      },
      {
        title: ' درخواست های موجودی ',
        link: '/pages/forms/inputs',
      },
      {
        title: ' درخواست های پرداخت قبض ',
        link: '/pages/forms/inputs',
      },
      {
        title: ' درخواست های نیکوکاری ',
        link: '/pages/forms/inputs',
      },
      {
        title: 'درخواست های خرید با فاکتور',
        link: '/pages/forms/inputs',
      },
      {
        title: 'درخواست های خرید شارژ',
        link: '/pages/forms/inputs',
      },
      {
        title: 'درخواست های ده گردش آخر',
        link: '/pages/forms/inputs',
      },
      {
        title: 'درخواست های انتقال کارت شبا',
        link: '/pages/forms/inputs',
      },
      {
        title: 'درخواست های خرید بسته',
        link: '/pages/forms/inputs',
      },
      {
        title: 'کارت‌های مقصد استعلام شده',
        link: '/pages/forms/inputs',
      },
      {
        title: 'کارت‌های مقصد استعلام شده',
        link: '/pages/forms/inputs',
      }
      
    ],
  },
  {
    title: 'گزارش خودرو',
    icon: 'car-outline',
    children: [
      {
        title: 'گزارش استعلام عوارض اتوبان',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش پرداخت عوارض اتوبان',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش استعلام طرح ترافیک',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش پرداخت طرح ترافیک',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش استعلام خلافی ',
        link: '/pages/forms/inputs',
      },
    ]
  },
  {
    title: 'گزارش درآمد',
    icon: 'bar-chart-2-outline',
    children: [
      {
        title: 'گزارش درآمد ماهانه',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش درآمد دوره‌ای',
        link: '/pages/forms/inputs',
      },
    ]
  },
  {
    title: 'مدیریت دسترسی ها',
    group: true,
  },
  {
    title: 'مدیریت ادمین',
    icon: 'edit-2-outline',
    children: [
      {
        title: 'مدیریت اپراتورها',
        link: '/pages/forms/inputs',
      },
      {
        title: 'مدیریت ابرآروان',
        link: '/pages/forms/inputs',
      },
      {
        title: 'نشست کاربران',
        link: '/pages/forms/inputs',
      },
      {
        title: 'خطاهای کاربران',
        link: '/pages/forms/inputs',
      },
      {
        title: 'لیست مجوزهای کاربران ',
        link: '/pages/forms/inputs',
      },
      {
        title: 'لیست لاگ های الستیک',
        link: '/pages/forms/inputs',
      },
    ]
  },

  {
    title: 'گزارش نموداری',
    group: true,

  },
  {
    title: 'گزارش نموداری',
    icon: 'bar-chart-2-outline',
    children: [
      {
        title: 'گزارش درخواست ها',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش لحظه ای',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش درخواست های موفق',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش درخواست های ناموفق',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش سابقه درخواست های ناموفق',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش سابقه درخواست های موفق انتقال وجه',
        link: '/pages/forms/inputs',
      },
      {
        title: 'گزارش در خواست های موفق خرید شارژ',
        link: '/pages/forms/inputs',
      },
    ]
  }
];
