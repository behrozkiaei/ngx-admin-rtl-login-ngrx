import {ChangeDetectionStrategy, ChangeDetectorRef, Component, OnDestroy, OnInit} from '@angular/core';
import { NbThemeService } from '@nebular/theme';
import { Store } from '@ngrx/store';
import { timeStamp } from 'console';
import { takeWhile } from 'rxjs/operators' ;
import { SolarData } from '../../@core/data/solar';
import { Dashboard } from '../../@core/models/dashboard.model';
import * as DashboardActions from "../../@core/state/Dashboard/dashboard.actions"
import { selectDashbord } from '../../@core/state/Dashboard/dashboard.selector';
interface CardSettings {
  title: string;
  iconClass: string;
  type: string;
}

@Component({
  selector: 'ngx-dashboard',
  styleUrls: ['./dashboard.component.scss'],
  templateUrl: './dashboard.component.html',
})
export class DashboardComponent implements OnDestroy,OnInit {
  DashboardData:Dashboard;
  DashboardData$ = this.store.select(selectDashbord).subscribe(res=>{
    if(res){
      this.prepareCards(res)
    }
  })
  private alive = true;

  solarValue: number;
  lightCard: CardSettings = {
    title: `اپراتور ها   `,
    iconClass: 'nb-lightbulb',
    type: 'primary',
  };
  rollerShadesCard: CardSettings = {
    title: 'پذیرنده ',
    iconClass: 'nb-roller-shades',
    type: 'success',
  };
  wirelessAudioCard: CardSettings = {
    title: 'پیشنهادات ',
    iconClass: 'nb-audio',
    type: 'info',
  };
  coffeeMakerCard: CardSettings = {
    title: 'تعداد کاربران  ',
    iconClass: 'nb-person',
    type: 'warning',
  };

  statusCards: string;

  commonStatusCardsSet: CardSettings[] = [
    this.lightCard,
    this.rollerShadesCard,
    this.wirelessAudioCard,
    this.coffeeMakerCard,
  ];

  statusCardsByThemes: {
    default: CardSettings[];
    cosmic: CardSettings[];
    corporate: CardSettings[];
    dark: CardSettings[];
  } = {
    default: this.commonStatusCardsSet,
    cosmic: this.commonStatusCardsSet,
    corporate: [
      {
        ...this.lightCard,
        type: 'warning',
      },
      {
        ...this.rollerShadesCard,
        type: 'primary',
      },
      {
        ...this.wirelessAudioCard,
        type: 'danger',
      },
      {
        ...this.coffeeMakerCard,
        type: 'info',
      },
    ],
    dark: this.commonStatusCardsSet,
  };

  constructor(private themeService: NbThemeService,
    private store : Store,
    private changeDetection: ChangeDetectorRef,
              private solarService: SolarData) {
    this.themeService.getJsTheme()
      .pipe(takeWhile(() => this.alive))
      .subscribe(theme => {
        this.statusCards = this.statusCardsByThemes[theme.name];
    });

    this.solarService.getSolarData()
      .pipe(takeWhile(() => this.alive))
      .subscribe((data) => {
        this.solarValue = data;
      });
  }

  ngOnDestroy() {
    this.alive = false;
  }
  ngOnInit(){
    this.store.dispatch(DashboardActions.load())

   
  }

  prepareCards(res : Dashboard){
    console.log(res?.operatorsCount)
    this.lightCard = {
      title: `اپراتور ها  ${res?.operatorsCount} `,
      iconClass: 'nb-lightbulb',
      type: 'primary',
    };
    this.rollerShadesCard = {
      title: `پذیرنده ${res?.merchantsCount}`,
      iconClass: 'nb-roller-shades',
      type: 'success',
    };
    this.wirelessAudioCard = {
      title: `پیشنهادات ${res?.suggestionsCount}`,
      iconClass: 'nb-audio',
      type: 'info',
    };
    this.coffeeMakerCard = {
      title: `تعداد کاربران   ${res?.usersCount}`,
      iconClass: 'nb-person',
      type: 'warning',
    };

    this.commonStatusCardsSet = [
      this.lightCard,
      this.rollerShadesCard,
      this.wirelessAudioCard,
      this.coffeeMakerCard,
    ];
    this.statusCardsByThemes = {
      default: this.commonStatusCardsSet,
      cosmic: this.commonStatusCardsSet,
      corporate: [
        {
          ...this.lightCard,
          type: 'warning',
        },
        {
          ...this.rollerShadesCard,
          type: 'primary',
        },
        {
          ...this.wirelessAudioCard,
          type: 'danger',
        },
        {
          ...this.coffeeMakerCard,
          type: 'info',
        },
      ],
      dark: this.commonStatusCardsSet,
    };

    this.themeService.getJsTheme()
    .pipe(takeWhile(() => this.alive))
    .subscribe(theme => {
      this.statusCards = this.statusCardsByThemes[theme.name];
      });
  }

}
